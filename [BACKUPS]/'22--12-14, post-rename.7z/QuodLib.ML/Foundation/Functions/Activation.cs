﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuodLib.ML.Foundation.Functions {
    public class Activation : Function {
        public delegate double ActivationPrimary(double weightedInput);
        public delegate double ActivationDerivative(double weightedInput);

        public ActivationPrimary Primary;
        public ActivationDerivative Derivative;

        public Activation(ActivationPrimary primary, ActivationDerivative derivative) {
            this.Primary = primary;
            this.Derivative = derivative;
        }
    }
}
