﻿namespace QuodLib.ML.Foundation.Functions.Standard {
    public static class Costs {
        public static readonly Cost Square = new(
            (ac, ex) => Math.Pow(ac - ex, 2),
            (ac, ex) => 2 * (ac - ex)
        );

    }
}