﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuodLib.ML.Foundation.Functions.Standard
{
    internal static class Main
    {
        internal static double Sigmoid(double weightedInput)
            => 1 / (1 + Math.Exp(-weightedInput));

        internal static double Step(double weightedInput)
            => weightedInput > 0 ? 1 : 0;
    }
}
