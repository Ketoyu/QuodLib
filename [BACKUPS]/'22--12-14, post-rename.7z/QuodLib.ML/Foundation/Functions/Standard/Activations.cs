﻿namespace QuodLib.ML.Foundation.Functions.Standard {
    public static class Activations {
        public static readonly Activation Step = new(Main.Step, wi => 0);
        public static readonly Activation Linear = new(wi => wi, _ => 1);

        public static readonly Activation ReLU = new(wi => Math.Max(0, wi), Main.Step);
        //TODO:     SiLU => wi / (1 + exp(-wi));

        public static readonly Activation Sigmoid = new(
            Main.Sigmoid,
            wi => {
                double s = Main.Sigmoid(wi);
                return s * (1 - s);
            }
        );

        //TODO:     HyperbolicTangent { e2w = Exp(2 * wi); return (e2w - 1) / (e2w + 1) }
    }
}