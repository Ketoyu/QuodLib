﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuodLib.ML.Foundation.Functions {
    public class Cost : Function {
        public delegate double CostPrimary(double actual, double expected);
        public delegate double CostDerivative(double actual, double expected);

        public CostPrimary Primary;
        public CostDerivative Derivative;

        public Cost(CostPrimary primary, CostDerivative derivative) {
            this.Primary = primary;
            this.Derivative = derivative;
        }
    }
}
