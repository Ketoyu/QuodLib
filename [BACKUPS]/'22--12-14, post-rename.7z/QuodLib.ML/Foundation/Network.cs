﻿using QuodLib.ML.Foundation.Functions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuodLib.ML.Foundation {
    public class Network {
        public IList<Layer> Layers { get; private set; }

        public Network(Activation activation, Cost cost, params int[] layerSizes) {
            Layers = new Layer[layerSizes.Length - 1];
            Parallel.For(0, layerSizes.Length, i => {
                Layers[i] = new Layer(layerSizes[i],
                    i == layerSizes.Length - 1
                        ? 0 
                        : layerSizes[i + 1],
                    activation, cost
                );
            });
        }

        private Network(Layer[] layers) {
            Layers = layers;
        }

        /// <summary>
        /// Compares the <see cref="DataPoint.ExpectedOutputs"/> vs actual-outputs for <i><b>one</b></i> <paramref name="dataPoint"/> across the output <see cref="Layer"/>.
        /// </summary>
        /// <param name="dataPoint"></param>
        /// <returns>The <b><i>total</i></b> comparison.</returns>
        public double Cost(DataPoint dataPoint) {
            double[] actual = Evaluate(dataPoint.Inputs);
            Layer outputLayer = Layers[Layers.Count - 1];

            return outputLayer.DataPointCost(actual, dataPoint.ExpectedOutputs);
        }

        /// <summary>
        /// Sends the <paramref name="inputs"/> through this <see cref="Network"/>.
        /// </summary>
        /// <param name="inputs"></param>
        /// <returns>The final output-set of this <see cref="Network"/>.</returns>
        public double[] Evaluate(double[] inputs) {
            foreach (Layer l in Layers)
                inputs = l.Evaluate(inputs);

            return inputs;
        }

        /// <summary>
        /// Compares the <see cref="DataPoint.ExpectedOutputs"/> vs actual-outputs for <i><b>all</b></i> <paramref name="dataPoints"/> across the output <see cref="Layer"/>.
        /// </summary>
        /// <param name="dataPoints"></param>
        /// <returns>The <b><i>average</i></b> comparison.</returns>
        public double AverageCost(IList<DataPoint> dataPoints) {
            double[] costs = new double[dataPoints.Count];
            Parallel.For(0, dataPoints.Count, i => costs[i] = Cost(dataPoints[i]));

            double totalCost = 0;
            foreach (double c in costs)
                totalCost += c;

            return totalCost / dataPoints.Count;
        }

        /// <summary>
        /// Locates the strongest output.
        /// </summary>
        /// <param name="inputs"></param>
        /// <returns>The index, within the output-<see cref="Layer"/>, of the node with the highest output.</returns>
        public int Classify(double[] inputs) {
            double[] outputs = Evaluate(inputs);

            double max = -1;
            int index = -1;
            for (int i = 0; i < outputs.Length; i++) {
                if (outputs[i] > max) {
                    max = outputs[i];
                    index = i;
                }
            }

            return index;
        }

        public void Learn(DataPoint[] trainingBatch, double learnRate) {
            ClearGradients(); //Fresh trainingBatch.

            foreach (DataPoint d in trainingBatch)
                AddGradients(d);

            ApplyGradients(learnRate / trainingBatch.Length);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="weight">(layerIndex, hasGradient, gradient, nodeIn, node, weight <c>=&gt;</c> newWeight)</param>
        /// <param name="bias">(layerIndex, hasGradient, gradient, node, bias <c>=&gt;</c> newBias)</param>
        public void Shake(Func<IWeightSample, double> weight, Func<IBiasSample, double> bias) {
            Parallel.For(0, Layers.Count, li => {
                Layer l = Layers[li];

                Parallel.For(0, l.Size, s => {
                    FullSample sample = new() {
                         LayerIndex = li,
                         NodeThis = s,
                         Bias = l.Biases[s],
                         HasGradients = l.HasGradients,
                         HasCost = l.HasCost,
                         Cost = l.RecentCost,
                         BiasGradient = l.BiasGradients[s]
                    };

                    for (int i = 0; i < l.NodesIn; i++) {
                        sample.Weight = l.Weights[i, s];
                        sample.WeightGradient = l.WeightGradients[i, s];

                        l.Weights[i, s] = weight(sample);
                    }

                    l.Biases[s] = bias(sample);
                });
            });
        }

        public Network Clone() {
            Layer[] layers = new Layer[Layers.Count];
            for (int i = 0; i < Layers.Count; i++)
                layers[i] = Layers[i].Clone();

            return new Network(layers);
        }

        public Network[] Clone(int count) {
            Network[] networks = new Network[count];

            Parallel.For(0, count, i => {
                networks[i] = Clone();
            });

            return networks;
        }

        private void AddGradients(DataPoint dataPoint) {
            Evaluate(dataPoint.Inputs); //This'll cause the layers to store the intermediate ("RecentXXXX") calculations.

            Layer outLayer = Layers[Layers.Count - 1];
            double[] nodeValues = outLayer.GetNodeValues(dataPoint.ExpectedOutputs);
            outLayer.AddGradiants(nodeValues);

            for (int i = Layers.Count - 2; i > 0; i--) {
                nodeValues = Layers[i].GetNodeValues(Layers[i+1], nodeValues);
                Layers[i].AddGradiants(nodeValues);
            }
        }

        private void ApplyGradients(double learnRate) {
            foreach (Layer l in Layers)
                l.ApplyGradients(learnRate);
        }
        private void ClearGradients() {
            foreach (Layer l in Layers)
                l.ClearGradientsAndCost();
        }
    }
}
