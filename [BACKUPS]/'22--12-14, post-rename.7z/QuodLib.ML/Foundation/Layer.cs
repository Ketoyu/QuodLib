﻿using QuodLib.ML.Foundation.Functions;

namespace QuodLib.ML.Foundation {
    public class Layer {
        public Activation Activation { get; private set; }
        public Cost Cost { get; private set; }
        public int NodesIn { get; private set; }
        public int Size { get; private set; }
        internal double[,] Weights { get; private set; }
        internal double[] Biases { get; private set; }

        #region Per batch
        public bool HasCost { get; private set; }
        public bool HasGradients { get; private set; }
        internal double[,] WeightGradients { get; private set; }
        internal double[] BiasGradients { get; private set; }
        #endregion //Per batch

        #region Per data-point
        private double[] RecentInputs { get; set; }
        private double[] RecentWeightedInputs { get; set; }
        private double[] RecentActivations { get; set; }
        internal double RecentCost { get; private set; }
        #endregion //Per data-point

        internal Layer(int nodesIn, int size, Activation activation, Cost cost) {
            NodesIn = nodesIn;
            Size = size;
            Activation = activation;
            Cost = cost;

            Weights = new double[NodesIn, Size];
            Biases = new double[Size];

            RandomizeWeights();
        }

        private Layer(int nodesIn, int size, Activation activation, Cost cost, double[,] weights, double[] biases) : this(nodesIn, size, activation, cost) {
            NodesIn = nodesIn;
            Size = size;
            Activation = activation;
            Cost = cost;

            Weights = new double[NodesIn, Size];
            for (int i = 0; i < nodesIn; i++)
                for (int s = 0; s < size; s++)
                    Weights[i, s] = weights[i, s];

            Biases = new double[Size];
            Array.Copy(biases, Biases, biases.Length);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="weights"></param>
        /// <param name="nodesIn"></param>
        /// <param name="layerSize"></param>
        /// <returns>ILGPU <i><b>(todo)</b></i></returns>
        internal static double[,] MergeWeights(double[][,] weights, int nodesIn, int layerSize) {
            double[,] newWeights = new double[nodesIn, layerSize];
            for (int w = 0; w < weights.Length; w++)
                for (int i = 0; i < nodesIn; i++)
                    for (int s = 0; s < layerSize; s++)
                        newWeights[i, s] += weights[w][i, s];

            for (int i = 0; i < nodesIn; i++)
                for (int s = 0; s < layerSize; s++)
                    newWeights[i, s] /= layerSize;

            return newWeights;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="biases"></param>
        /// <param name="layerSize"></param>
        /// <returns>ILGPU <i><b>(todo)</b></i></returns>
        internal static double[] MergeBiases(double[][] biases, int layerSize) {
            double[] newBiases = new double[layerSize];
            for (int b = 0; b < biases.Length; b++)
                for (int s = 0; s < layerSize; s++)
                    newBiases[s] += biases[b][s];

            for (int s = 0; s < layerSize; s++)
                newBiases[s] /= layerSize;

            return newBiases;
        }

        internal void Merge(IList<Layer> siblings) {
            WeightGradients = MergeWeights(siblings.Select(l => l.Weights).ToArray(), NodesIn, Size);
            BiasGradients = MergeBiases(siblings.Select(l => l.Biases).ToArray(), Size);
        }

        public Layer Clone()
            => new(NodesIn, Size, Activation, Cost, Weights, Biases);

        public Layer[] Clone(int count) {
            Layer[] layers = new Layer[count];

            Parallel.For(0, count, i => {
                layers[i] = Clone();
            });

            return layers.ToArray();
        }


        /// <summary>
        /// Compares the expected- vs actual-values for <b><i>one</i></b> data-point across this <see cref="Layer"/>.
        /// </summary>
        /// <param name="actualOutputs"></param>
        /// <param name="expectedOutputs"></param>
        /// <returns>The <b><i>total</i></b> comparison.</returns>
        internal double DataPointCost(double[] actualOutputs, double[] expectedOutputs) {
            double[] costs = new double[expectedOutputs.Length];
            Parallel.For(0, Size, i => costs[i] = Cost.Primary(actualOutputs[i], expectedOutputs[i]));

            double cost = 0;
            foreach(double c in costs)
                cost += c;

            RecentCost = cost;
            return cost;
        }

        /// <summary>
        /// Processes the <paramref name="inputs"/> <i>(<b>one</b> data-point)</i> into an output of this <see cref="Layer"/>.
        /// </summary>
        /// <param name="inputs"></param>
        /// <returns>The output for this <see cref="Layer"/>.</returns>
        internal double[] Evaluate(double[] inputs) {
            RecentInputs = inputs;

            double[] activations = new double[Size];

            Parallel.For(0, Size, s => {
                RecentWeightedInputs[s] = Biases[s];
                for (int i = 0; i < NodesIn; i++)
                    RecentWeightedInputs[s] += inputs[i] * Weights[i, s];

                activations[s] = Activation.Primary(RecentWeightedInputs[s]);
            });

            RecentActivations = activations;
            return activations;
        }

        /// <summary>
        /// <i><b>d</b></i>Activation * <i><b>d</b></i>Cost, for each node.
        /// </summary>
        /// <param name="expectedOutputs"></param>
        /// <returns></returns>
        internal double[] GetNodeValues(double[] expectedOutputs) {
            double[] nodeValues = new double[expectedOutputs.Length];

            Parallel.For(0, nodeValues.Length, i => {
                nodeValues[i] = Activation.Derivative(RecentWeightedInputs[i]) * Cost.Derivative(RecentActivations[i], expectedOutputs[i]);
            });

            return nodeValues;
        }

        /// <summary>
        /// <i><b>d</b></i>Activation * <i><b>d</b></i>Cost, for each node.
        /// </summary>
        /// <param name="succesor"></param>
        /// <param name="itsNodeValues"></param>
        /// <returns></returns>
        internal double[] GetNodeValues(Layer succesor, double[] itsNodeValues) {
            double[] nodeValues = new double[Size];

            Parallel.For(0, nodeValues.Length, s => {
                for (int iSuccessor = 0; iSuccessor < itsNodeValues.Length; iSuccessor++)
                    nodeValues[s] += succesor.Weights[s, iSuccessor] * itsNodeValues[iSuccessor];

                nodeValues[s] *= Activation.Derivative(RecentWeightedInputs[s]);
            });

            return nodeValues;
        }

        /// <summary>
        /// Adds one data-point's worth of node-values to running weight- and bias-gradient totals.
        /// </summary>
        /// <param name="nodeValues">The node-values computed by this <see cref="Layer"/>.</param>
        /// <remarks><i>Later, you'll need to divide these by the length of the current data-set or -subset.</i></remarks>
        internal void AddGradiants(double[] nodeValues) {
            for (int s = 0; s < Size; s++) {
                for (int i = 0; i < NodesIn; i++)
                    WeightGradients[i, s] += RecentInputs[i] * nodeValues[s];

                BiasGradients[s] += nodeValues[s]; //** (dInput:dBias is just 1 * bias)
            }
        }

        /// <summary>
        /// Uses this <see cref="Layer"/>'s gradients to update its weights and biases, scaled by the <paramref name="learnRate"/>.
        /// </summary>
        /// <param name="learnRate"></param>
        /// <remarks><i>If the weight- and bias-gradients were computed using many data-points, you must divide <paramref name="learnRate"/> by the length of the data-set or -subset before passing it in.</i></remarks>
        internal void ApplyGradients(double learnRate) {
            for (int s = 0; s < Size; s++) {
                Biases[s] -= BiasGradients[s] * learnRate;
                for (int i = 0; i < NodesIn; i++)
                    Weights[i, s] = WeightGradients[i, s] * learnRate;
            }

            HasGradients = true;
        }

        /// <summary>
        /// Sets all weights to a random value.
        /// </summary>
        /// <remarks><i>Used during initialization of this <see cref="Layer"/> within a fresh <see cref="Network"/>.</i></remarks>
        private void RandomizeWeights() {
            Random rand = new();

            for (int i = 0; i < NodesIn; i++)
                for (int s = 0; s < Size; s++)
                    Weights[i, s] = (rand.NextDouble() * 2 - 1) / Math.Sqrt(NodesIn);
        }

        /// <summary>
        /// Resets all weight- and bias-gradients to zero, to prepare for a new batch of data-points.
        /// </summary>
        internal void ClearGradientsAndCost() {
            HasGradients = false;
            HasCost = false;
            RecentCost = 0;

            for (int s = 0; s < Size; s++) {
                for (int i = 0; i < NodesIn; i++)
                    WeightGradients[i, s] = 0;

                BiasGradients[s] = 0;
            }
        }

    }
}