﻿namespace QuodLib.ML.Foundation {
    public class DataPoint {
        public double[] Inputs { get; init; }
        public double[] ExpectedOutputs { get; init; }
    }
}