﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuodLib.Database.ADO {
    public class Static {
        public static string ConnectionString { get; set; } = string.Empty;
    }
}
